/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cohort2;

import java.io.IOException;
import java.io.PrintWriter;
import javax.inject.Inject;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "FirstServlet", urlPatterns = {"/FS"}, 
        initParams = @WebInitParam(name = "initParam1", value = "888888888") )
public class FirstServlet extends HttpServlet {
    
    @Inject
    TestBean tb;
    
    private ServletConfig config;
    
    @Override
    public void init(ServletConfig config) throws ServletException{
        super.init(config);
        this.config = config;
        // DB - what is the IP 
        // talk a diff application - username/password 
        // diffSystem.getConnect("weblogic","welcome1");
        String initValue = (config.getInitParameter("initParam1") != null) ? config.getInitParameter("initParam1").toString() : "XXXXXXX";
        ServletContext ctx = config.getServletContext();
        String ctxValue = (ctx.getInitParameter("ctxParam1") != null) ? ctx.getInitParameter("ctxParam1").toString() : "XXXXXXX";
        
        System.out.println(" ==================================");
        System.out.println(" Servlet Context / Globla Init Param " + ctxValue);
        System.out.println(" Servlet Config / Local Init Param " + initValue);
        System.out.println(" ==================================");
    }
    @Override
   public void destroy(){
        System.out.println(" ==================================");
        System.out.println(" Servlet Destroy Method");
        System.out.println(" ==================================");
    }

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Resquet - from the browser to the Server ---  .GET_Methods
        // Response === Mostly you are sending the response back to browser - Set / out.println
        Cookie [] cookies = request.getCookies();
        if(cookies != null) {
        for(Cookie c : cookies){
            System.out.println(c.getName() + " :: " + c.getValue() + " :: " + c.getMaxAge());
        }}
        
        

        HttpSession sess = request.getSession();
        
        if(sess.isNew()){
            sess.setAttribute("CTR", 1);
            Cookie c = new Cookie("CTR", "" + 1);
            c.setMaxAge(60*60);
            response.addCookie(c);
            if(request.getMethod().equals("POST")) {
            
                String cNameSP = request.getParameter("custName") != null ? request.getParameter("custName").toString() : "default";
                sess.setAttribute("CUSTNAME_SP", cNameSP);
            
                Cookie c1 = new Cookie("CNAME", cNameSP);
                c1.setMaxAge(3600);
                response.addCookie(c1);
                String cNameFP = request.getAttribute("CNAME") != null ? request.getAttribute("CNAME").toString() : "DEFAULT";
                sess.setAttribute("CUSTNAME_FP", cNameFP);
                
                tb.setName(cNameSP.replace("s", "S"));
                sess.setAttribute("TBean", tb);
            }
        }else {
            int ctr = Integer.parseInt((sess.getAttribute("CTR")).toString());
            sess.setAttribute("CTR", ++ctr);
              Cookie c = new Cookie("CTR", "" + (ctr));
            response.addCookie(c);
        }
        
        request.getRequestDispatcher("SS").forward(request, response);
        
//        response.setContentType("text/html;charset=UTF-8");
//        try (PrintWriter out = response.getWriter()) {
//            /* TODO output your page here. You may use following sample code. */
//            out.println("<!DOCTYPE html>");
//            out.println("<html>");
//            out.println("<head>");
//            out.println("<title>Servlet FirstServlet</title>");            
//            out.println("</head>");
//            out.println("<body>");
//            out.println("<h1>Servlet FirstServlet at " + request.getContextPath() + "</h1>");
//            out.println("<a href='/'> Go Back to Home Page </a>");
//            out.println("<img src=\"http://localhost:7001/myImage.jpeg\" />");
//            out.println("</body>");
//            out.println("</html>");
//        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}

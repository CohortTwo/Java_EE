/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cohort2;

import java.util.ArrayList;
import java.util.List;
import javax.ws.rs.NotFoundException;


public class EmployeeService {

    private static List<Employee> employees = new ArrayList<Employee>();

    public EmployeeService() {
        if (employees.isEmpty()) {
            employees.add(new Employee(100, "John", "emp1@org.com", 3000));
            employees.add(new Employee(101, "Jane", "emp2@org.com", 5000));
            employees.add(new Employee(102, "Jake", "emp3@org.com", 9000));
        }
    }

    public List<Employee> fetchAll() {
        employees.forEach(System.out::println);
        return employees;
    }

    public Employee fetchBy(int id) throws NotFoundException {
        for (Employee employee : employees) {
            System.out.println(" Employees fetched " + employee.getId());
            if (id == employee.getId()) {
                System.out.println(" Employee Fetched :: " + employee);
                return employee;
            } 
        }
        return null;
    }

    public Employee create(Employee employee) {
        employees.add(employee);
        System.out.println(" Employee Added " + employee);
        return employee;
    }

    public Employee update(Employee employee) {
        for (Employee employee2 : employees) {
            if (employee.getId() == employee2.getId()) {
                employees.remove(employee2);
                employees.add(employee);
                System.out.println(" Employee Updated  ::" + employee);
                return employee;
            }
        }
        return null;
    }

    public Employee delete(int id) throws NotFoundException {
        Employee employee2 = this.fetchBy(id);
        employees.remove(employee2);
        System.out.println(" Employee Deleted :: " + employee2);
        return employee2;
    }
}

package andy;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.json.Json;
import javax.json.JsonObject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

@Path("/account")
@RequestScoped
public class AccountResource {

	@Inject
	UserDAO userDAO;

	@GET
	@Path("/userid")
	@Produces(MediaType.APPLICATION_JSON) 
	public Response getUserId(@Context HttpServletRequest request) {
		System.out.println(
				"Class: AccountResource | Method: getUserId() executed)");

		HttpSession session = request.getSession();
		if (!UserAccessValidation.isValidSession(session)) 
			return Response.status(401).build();

		User user = 
			userDAO.getUserById((Integer)session.getAttribute("userid")).get();

		Status statusCode = UserAccessValidation.isValidUser(user);

		if (statusCode != Status.OK) 
				return Response.status(statusCode).build();

		JsonObject userId = Json.createObjectBuilder()
			.add("userId", user.getUserId())
			.build();
		return Response.ok(userId).build();
	}

	@GET
	@Path("/username")
	@Produces(MediaType.APPLICATION_JSON) 
	public Response getUserName(@Context HttpServletRequest request) {
		System.out.println(
				"Class: AccountResource | Method: getUserName() executed");

		HttpSession session = request.getSession();
		if (!UserAccessValidation.isValidSession(session)) 
			return Response.status(401).build();

		User user = 
			userDAO.getUserById((Integer)session.getAttribute("userid")).get();

		Status statusCode = UserAccessValidation.isValidUser(user);

		if (statusCode != Status.OK) 
				return Response.status(statusCode).build();

		JsonObject userName = Json.createObjectBuilder()
			.add("userName", user.getUserName())
			.build();
		return Response.ok(userName).build();
	}

	@GET
	@Path("/iswrite")
	@Produces(MediaType.APPLICATION_JSON) 
	public Response isWrite(@Context HttpServletRequest request) {
		System.out.println(
				"Class: AccountResource | Method: isWrite() executed");

		HttpSession session = request.getSession();
		if (!UserAccessValidation.isValidSession(session)) 
			return Response.status(401).build();

		User user = 
			userDAO.getUserById((Integer)session.getAttribute("userid")).get();

		Status statusCode = UserAccessValidation.isValidUser(user);

		if (statusCode != Status.OK) 
				return Response.status(statusCode).build();

		JsonObject userName = Json.createObjectBuilder()
			.add("isWrite", user.isWrite())
			.build();
		return Response.ok(userName).build();
	}

	@GET
	@Path("/isadmin")
	@Produces(MediaType.APPLICATION_JSON) 
	public Response isAdmin(@Context HttpServletRequest request) {
		System.out.println(
				"Class: AccountResource | Method: isAdmin() executed");

		HttpSession session = request.getSession();
		if (!UserAccessValidation.isValidSession(session)) 
			return Response.status(401).build();

		User user = 
			userDAO.getUserById((Integer)session.getAttribute("userid")).get();

		Status statusCode = UserAccessValidation.isValidUser(user);

		if (statusCode != Status.OK) 
				return Response.status(statusCode).build();

		JsonObject isAdmin = Json.createObjectBuilder()
			.add("isAdmin", user.isAdmin())
			.build();
		return Response.ok(isAdmin).build();
	}
}

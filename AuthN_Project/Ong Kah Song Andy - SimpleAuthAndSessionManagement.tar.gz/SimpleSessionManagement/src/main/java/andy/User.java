package andy;

public class User {
	private int userId;
	private String userName;
	private String password; 
	private boolean inUse;
	private boolean write;
	private boolean enable; 
	private boolean admin;

	public User() {
	}

	public User(int userId, String userName, String password, boolean inUse, boolean write, boolean enable,
			boolean admin) {
		this.userId = userId;
		this.userName = userName;
		this.password = password;
		this.inUse = inUse;
		this.write = write;
		this.enable = enable;
		this.admin = admin;
	}

	public User(int userId, String userName, String password, int inUse, int write, int enable,
			int admin) {
		this.userId = userId;
		this.userName = userName;
		this.password = password;
		this.inUse = inUse > 0 ? true : false;
		this.write = write > 0 ? true : false;
		this.enable = enable > 0 ? true : false;
		this.admin = admin > 0 ? true : false;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public boolean isInUse() {
		return inUse;
	}

	public void setInUse(boolean inUse) {
		this.inUse = inUse;
	}

	public boolean isWrite() {
		return write;
	}

	public void setWrite(boolean write) {
		this.write = write;
	}

	public boolean isEnable() {
		return enable;
	}

	public void setEnable(boolean enable) {
		this.enable = enable;
	}

	public boolean isAdmin() {
		return admin;
	}

	public void setAdmin(boolean admin) {
		this.admin = admin;
	}

	@Override
	public String toString() {
		return "User [admin=" + admin + ", enable=" + enable + ", inUse=" + inUse + ", password=" + password
				+ ", userId=" + userId + ", userName=" + userName + ", write=" + write + "]";
	}

}

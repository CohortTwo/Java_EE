package andy;

import java.io.IOException;
import java.util.Optional;

import javax.inject.Inject;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "LogoutServlet", urlPatterns = {"/LogoutServlet"})
public class LogoutServlet extends HttpServlet {
	@Inject 
	AuthBean authBean;

	@Override
	protected void doGet(HttpServletRequest request, 
			HttpServletResponse response) {
		logoutPageRequests(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, 
			HttpServletResponse response) {
		logoutPageRequests(request, response);
	}

	protected void logoutPageRequests(HttpServletRequest request, 
			HttpServletResponse response) {
		HttpSession session = request.getSession();
		Integer userid = (Integer)session.getAttribute("userid");
		try {
			if (session.getAttribute("username") == null ) 
				request.getRequestDispatcher("login.jsp").forward(request, response);
			authBean.setLoginStatus(userid, false);
			session.invalidate();
			response.setContentType("text/html");
			response.sendRedirect("http://localhost:8080/SimpleSessionManagement/login.jsp");
		} catch (ServletException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		} 
	}
}

package andy;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.enterprise.context.RequestScoped;
import javax.sql.DataSource;

@RequestScoped
public class UserDAOImpl implements UserDAO {
	@Resource(name = "jdbc/hr")
	DataSource ds;
	Connection conn;
	List<User> users;

	public UserDAOImpl() {
		conn = null;
		users = new ArrayList<>();
	}

	@Override
	public Optional<List<User>> getAllUser() {
		// Connection conn = connectDB();
		try {
			conn = ds.getConnection();
			ResultSet rs = conn.createStatement()
				.executeQuery("select * from users");
			if (rs.isBeforeFirst()) {
				 while (rs.next()) {
					users.add(new User( 
								rs.getInt("userid"),
								rs.getString("username"),
								rs.getString("password"),
								rs.getInt("inuse"),
								rs.getInt("write"),
								rs.getInt("enabled"),
								rs.getInt("admin")));
				 } 
				 return Optional.of(users);
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try { conn.close(); }
			catch (SQLException ex) {}
		}
		return Optional.empty();
	}

	@Override
    public Optional<User> getUserById(int userId) {
		// Connection conn = connectDB();
		try {
			conn = ds.getConnection();
			ResultSet rs = conn.createStatement()
				.executeQuery("select * from users where userid=" + userId);
			if (rs.isBeforeFirst()) {
				rs.next();
				return Optional.of(new User(
							rs.getInt("userid"), 
							rs.getString("username"), 
							rs.getString("password"), 
							rs.getInt("inuse"), 
							rs.getInt("write"), 
							rs.getInt("enabled"), 
							rs.getInt("admin")));
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try { conn.close(); }
			catch (SQLException ex) {}
		}
		return Optional.empty();
	}

	@Override
    public boolean addUser(User user) {
		// Connection conn = connectDB();
		try {
			conn = ds.getConnection();
			conn.createStatement() 
				.executeUpdate(
						"INSERT INTO users " + 
						"(userid, username, password, inuse," +
						" write, enabled, admin)" +
						"VALUES (" +
							user.getUserId() + ", '" +
						    user.getUserName() + "', '" +
						    user.getPassword() + "', '" +
						    user.isInUse() + "', '" +
						    user.isWrite() + "', '" +
						    user.isEnable() + "', "  +
						    user.isAdmin() + ") " 
						);
		} catch (SQLException ex) {
			ex.printStackTrace();
			return false;
		} finally {
			try { conn.close(); } 
			catch (SQLException ex) {}
		}
		return true;
	}

	@Override
	public boolean delUser(int userId) {
		// Connection conn = connectDB();
		try {
			conn = ds.getConnection();
			conn.createStatement().executeUpdate( 
					"DELETE FROM users " + 
					"WHERE userid = " + userId);
		} catch (SQLException ex) {
			ex.printStackTrace();
			return false;
		} finally {
			try { conn.close(); } 
			catch (SQLException ex) {}
		}
		return true;
	}

	@Override
    public boolean updateUser(int userId, User user) {
		// Connection conn = connectDB();
		try {
			conn = ds.getConnection();
			conn.createStatement() 
				.executeUpdate(
						"UPDATE users " + 
						"SET " +
						"userid = '" + user.getUserId() + "', " +
						"username = '" + user.getUserName() + "', " +
						"password = '" + user.getPassword() + "', " +
						"inuse = '" + user.isInUse() + "', " +
						"write = '" + user.isWrite() + "', "  +
						"enabled = " + user.isEnable() + ", "  +
						"admin = " + user.isAdmin() +
						" WHERE userid = " + userId
						);
		} catch (SQLException ex) {
			ex.printStackTrace();
			return false;
		} finally {
			try { conn.close(); } 
			catch (SQLException ex) {}
		}
		return true;
	}


	/*
	private Connection connectDB() {
		try {
			// App server will require this
			Class.forName("org.sqlite.JDBC");
			conn = DriverManager.getConnection( 
					"jdbc:sqlite:/home/andy/code/hr/src/main/resources/hr.db");
		} catch (SQLException ex) {
			ex.printStackTrace();
		} catch (ClassNotFoundException ex) {
			ex.printStackTrace();
		}
		return conn;
	}
	*/
}

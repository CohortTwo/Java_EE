package andy;

import java.util.List;
import java.util.Optional;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

@Path("/users")
@RequestScoped
public class UserResource {
	@Inject
	UserDAO userDAO;

	@GET
	@Path("/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getUser(
		@Context HttpServletRequest request, @PathParam("id") int id) {
		System.out.println("getUser() executed");

		HttpSession session = request.getSession();
		if (!UserAccessValidation.isValidSession(session)) 
			return Response.status(401).build();

		User user = 
			userDAO.getUserById((Integer)session.getAttribute("userid")).get();

		if (!user.isAdmin()) 
			return Response.status(403).build();

		Status statusCode = UserAccessValidation.isValidUser(user);
		if (statusCode != Status.OK) 
				return Response.status(statusCode).build();

		Optional<User> result = userDAO.getUserById(id);
		if (result.isPresent())
			return Response.ok(result.get()).build();
		else 
			return Response.status(404).build();
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Response getUsers(@Context HttpServletRequest request) {
		System.out.println("getUsers() executed");

		HttpSession session = request.getSession();
		if (!UserAccessValidation.isValidSession(session)) 
			return Response.status(401).build();

		User user = userDAO.getUserById((Integer)session.getAttribute("userid")).get();

		if (!user.isAdmin()) 
			return Response.status(403).build();

		Status statusCode = UserAccessValidation.isValidUser(user);
		if (statusCode != Status.OK) 
				return Response.status(statusCode).build();

		Optional<List<User>> userList = userDAO.getAllUser();
		return Response.ok(userList.get()).build();
	}


}

package andy;

import java.util.Arrays;

import javax.servlet.http.HttpSession;
import javax.ws.rs.core.Response.Status;

public class UserAccessValidation {
	public static Status isValidUser(User user) {
		if (!user.isEnable()) 
			return Status.UNAUTHORIZED;
		else if (!user.isInUse()) 
			return Status.INTERNAL_SERVER_ERROR;
		else 
			return Status.OK;
	}

	public static boolean isValidSession(HttpSession session) {
		if (session == null) 
			return false;
		String[] attrNames = session.getValueNames();
		Boolean hasUserId = Arrays.stream(attrNames)
			.anyMatch(e -> e.equals("userid"));
		Boolean hasUsername = Arrays.stream(attrNames)
			.anyMatch(e -> e.equals("username"));
		if (!hasUserId || !hasUsername) 
			return false;
		return true;
	}

	/*
	 * You were trying to trim the valiation code....
	 */
	/*
	public static Status isValidAccount(HttpSession session) {
		if (isValidSession(session))
			return Status.UNAUTHORIZED;
		User user = 
			userDAO.getUserById((Integer)session.getAttribute("userid")).get();
		return isValidUser(user);
	}
	*/
}

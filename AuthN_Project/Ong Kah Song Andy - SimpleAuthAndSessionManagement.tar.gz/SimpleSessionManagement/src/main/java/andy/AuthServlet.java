package andy;

import java.util.List;
import java.util.Optional;

import javax.inject.Inject;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "AuthServlet", urlPatterns = {"/AuthServlet"})
public class AuthServlet extends HttpServlet {

    @Inject 
    AuthBean authBean;

	@Override
	protected void doGet(HttpServletRequest request, 
			HttpServletResponse response) {
		loginPageRequests(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, 
			HttpServletResponse response) {
		loginPageRequests(request, response);
	}

	protected void loginPageRequests(HttpServletRequest request, 
			HttpServletResponse response) {

		try {

			HttpSession session = request.getSession();


			if (session.getAttribute("username") == null && 
					!request.getParameterMap().containsKey("action")) {

				request
					.getRequestDispatcher("login.jsp")
					.forward(request, response);
				return;

			} else if (session.getAttribute("username") != null) {

				request
					.getRequestDispatcher("home.jsp")
					.forward(request, response);
				return;
			}

			String username = request.getParameter("usr_name").trim();
			String password = request.getParameter("pwd").trim();
			Optional<User> data = authBean.login(username, password);

			if (data.isPresent()) {
				User user = data.get();
				session.setAttribute("username", user.getUserName());
				session.setAttribute("userid", user.getUserId());

				// Base on the 2 following session attributes write and admin
				// There should be a database check before actual modification
				// are made, be they modifications on the user table or the
				// employee tables.
				session.setAttribute("write", user.isWrite());
				session.setAttribute("admin", user.isAdmin());
				request.removeAttribute("action");
				authBean.setLoginStatus(user.getUserId(), true);
				request
					.getRequestDispatcher("home.jsp")
					.forward(request, response);
				return;
			} else {
				request.setAttribute("error", "invalid");
				request
					.getRequestDispatcher("login.jsp")
					.forward(request, response);
			}

		} catch (Exception ex) {ex.printStackTrace();} 
	}
}

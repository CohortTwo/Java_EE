package andy;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.annotation.ManagedBean;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.enterprise.context.RequestScoped;
import javax.sql.DataSource;

// @Stateless
@RequestScoped
public class AuthBean {
	@Resource(name = "jdbc/hr")
	DataSource ds;

	public Optional<User> login(String user, String pwd) {
		System.err.println("login method entered");
		User userObj = null;
		Connection conn = null;
		String stmt = 
			"select * from users where " + 
			" username" + "='" + user + "' and" +
			" password" + "='" + pwd + "'";
		try {
			conn = ds.getConnection(); 
			ResultSet rs = conn.createStatement().executeQuery(stmt);
			if (rs.isBeforeFirst()) {
				while (rs.next()) {
					userObj = new User(
							rs.getInt("userid"), 
							rs.getString("username"), 
							rs.getString("password"), 
							1, 
							rs.getInt("write"), 
							rs.getInt("enabled"), 
							rs.getInt("admin"));
				}
			} else 
				return Optional.empty();
		} catch (SQLException ex) { 
			ex.printStackTrace(); 
		} finally {
			try { conn.close(); }
			catch (SQLException ex) {}
		}
		return Optional.ofNullable(userObj);
	}

	public void setLoginStatus(int userid, boolean loginStatus) {
		String stmt = 
			loginStatus ? 
			"UPDATE users SET inuse=1 WHERE userid=" + userid :
			"UPDATE users SET inuse=0 WHERE userid=" + userid;
		Connection conn = null;
		try {
			conn = ds.getConnection();		
			conn.createStatement().executeUpdate(stmt);
		} catch (SQLException ex) { 
			ex.printStackTrace(); 
		} finally {
			try { conn.close(); }
			catch (SQLException ex) {}
		}
	}
}

package andy;

import java.util.List;
import java.util.Optional;

import javax.enterprise.context.RequestScoped;

@RequestScoped
public interface UserDAO {
    Optional<List<User>> getAllUser();
    Optional<User> getUserById(int userId);
    boolean addUser(User user);
    boolean delUser(int userId);
    boolean updateUser(int userId, User user);
}


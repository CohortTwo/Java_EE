/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.apparel;

import java.util.List;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

/**
 *
 * @author blueg
 */
@Path("/apparel")
public class ApparelResource {
    private ApparelOperations appareloperations = new ApparelOperations();
    
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public List<Apparel> getAll() {
        return appareloperations.getAll();
    }
    
    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getBy(@PathParam("id") int id) {
        Apparel apparel = appareloperations.getBy(id);
        return Response.ok().entity(apparel).build();
    }
    
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Response create(Apparel apparel) {
        // create notification
        appareloperations.create(apparel);
        return Response.ok().status(Response.Status.CREATED).build();
    }
    
    @DELETE
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response delete(@PathParam("id") int id) {
        appareloperations.delete(id);
        return Response.ok().status(Response.Status.FOUND).build();
    }
    
    @PUT
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Response update(@PathParam("id") int id, Apparel apparel) {
        // create notification
        appareloperations.update(apparel);
        return Response.ok().status(Response.Status.FOUND).build();
    }
    
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.apparel;

import java.util.ArrayList;
import java.util.List;
import javax.ws.rs.NotFoundException;

/**
 *
 * @author blueg
 */
public class ApparelOperations {
    private static List<Apparel> apparels = new ArrayList<Apparel>();
    
    public ApparelOperations() {
        if (apparels.isEmpty()) {
            apparels.add(new Apparel(1, 29.99, "M","Red Jeans",10));
            apparels.add(new Apparel(2, 30.00, "XL","Blue Shorts",20));
            apparels.add(new Apparel(3, 13.99, "S","Pink Shirt",30));
        }
    }
    
    public List<Apparel> getAll() {
        apparels.forEach(System.out::println);
        return apparels;
    }
    
    public Apparel getBy(int id) throws NotFoundException {
        for (Apparel apparel : apparels) {
            System.out.println(" Apparel fetched " + apparel.getId());
            if (id == apparel.getId()) {
                System.out.println(" Apparel fetched :: " + apparel);
                return apparel;
            } 
        }
        return null;
    }
    
    public Apparel create(Apparel apparel){
        apparels.add(apparel);
        System.out.println("Apparel record has been added");
        return apparel;
    }
    
    public Apparel delete(int id)throws NotFoundException{
        Apparel appareldel = this.getBy(id); //apparel to delete
        apparels.remove(appareldel);
        System.out.println(" Apparel record has been deleted: " + appareldel);
        return appareldel;
    }
    
    public Apparel update(Apparel apparel){
        for (Apparel apparelup : apparels) {
            if (apparel.getId() == apparelup.getId()) {
                apparels.remove(apparelup);
                apparels.add(apparel);
                System.out.println(" Apparel record has been updated:" + apparel);
                return apparel;
            }
        }
        return null;
    }
}

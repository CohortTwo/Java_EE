
package com.cohort2;

import javax.faces.bean.SessionScoped;
enum Section 
{ 
  FIRST, 	ECOMONY;
} 
@SessionScoped
public class Seat {
    private int id;
    private String row;
    private String column;
    private Section section;
    private double price;
    private boolean isBooked;
    private String instruction;

    public Seat() {
        this.price = 0;
    }

    public Seat(int id, String row, String column, Section section, boolean isBooked, String instruction) {
        this.id = id;
        this.row = row;
        this.column = column;
        this.section = section;
        this.price = 0;
        this.isBooked = isBooked;
        this.instruction = instruction;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getRow() {
        return row;
    }

    public void setRow(String row) {
        this.row = row;
    }

    public String getColumn() {
        return column;
    }

    public void setColumn(String column) {
        this.column = column;
    }

    public Section getSection() {
        return section;
    }

    public void setSection(Section section) {
        this.section = section;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public boolean isIsBooked() {
        return isBooked;
    }

    public void setIsBooked(boolean isBooked) {
        this.isBooked = isBooked;
    }

    public String getInstruction() {
        return instruction;
    }

    public void setInstruction(String instruction) {
        this.instruction = instruction;
    }

    @Override
    public String toString() {
        return "Seat{" + "id=" + id + ", row=" + row + ", column=" + column + ", section=" + section + ", price=" + price + ", isBooked=" + isBooked + ", instruction=" + instruction + '}';
    }
    
}

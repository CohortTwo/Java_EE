package com.cohort2;

import java.util.ArrayList;
import java.util.List;
import javax.ws.rs.NotFoundException;

public class SeatService {

    private static List<Seat> seats = new ArrayList<Seat>();

    public SeatService() {
        if (seats.isEmpty()) {
            seats.add(new Seat(1, "A", "1", Section.valueOf("FIRST"), false, "a@abc.com"));
            seats.add(new Seat(2, "A", "2", Section.valueOf("FIRST"), false, "With baby"));
            seats.add(new Seat(3, "A", "3", Section.valueOf("FIRST"), false, ""));
            seats.add(new Seat(4, "A", "4", Section.valueOf("FIRST"), false, "with elderly"));
            
            seats.add(new Seat(5, "B", "1", Section.valueOf("ECOMONY"), false, ""));
            seats.add(new Seat(6, "B", "2", Section.valueOf("ECOMONY"), false, "veg"));
            seats.add(new Seat(7, "B", "3", Section.valueOf("ECOMONY"), false, "Japanese food"));
            seats.add(new Seat(8, "B", "4", Section.valueOf("ECOMONY"), false, ""));
        }
    }

    public List<Seat> fetchAll() {
        System.out.println(seats.size());
        seats.forEach(System.out::println);
        return seats;
    }

    public Seat fetchBy(int id) throws NotFoundException {
        for (Seat seat : seats) {
            System.out.println(" seats fetched " + seat.getId());
            if (id == seat.getId()) {
                System.out.println(" seat Fetched :: " + seat);
                return seat;
            }
        }
        return null;
    }

    public Seat create(Seat seat) {
        seats.add(seat);
        System.out.println(" Seat Added " + seat);
        return seat;
    }

    public Seat update(Seat seat) {
        delete(seat.getId());
        seats.add(seat);
//        for (Seat seat2 : seats) {
//            if (seat.getId() == seat2.getId()) {
//                seats.remove(seat);
//                seats.add(seat);
//                System.out.println(" seat Updated  :" + seat);
//                return seat;
//            }
//        }
        return null;
    }

    public Seat delete(int id) throws NotFoundException {
        Seat seat2 = this.fetchBy(id);
        seats.remove(seat2);
        System.out.println(" Seat Deleted :: " + seat2);
        return seat2;
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cohort2;

import java.util.List;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;


@Path("/seats")
public class SeatResource {

    private SeatService seatService = new SeatService();

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public List<Seat> fetchAll() {
        return seatService.fetchAll();
    }

    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response fetchBy(@PathParam("id") int id) {
        System.out.println("FETCH CALLED");
        Seat seat = seatService.fetchBy(id);
        return Response.ok().entity(seat).build();
    }

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Response create(Seat seat) {
        // create notification
        seatService.create(seat);
        return Response.ok().status(Status.CREATED).build();
    }

    @PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response update(@PathParam("id") int id, Seat seat) {
        System.out.println("UPDATE CALLED");
        seatService.update(seat);
        return Response.ok().status(Status.FOUND).build();
    }

    @DELETE
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response delete(@PathParam("id") int id) {
        System.out.println("DELETE CALLED");
        seatService.delete(id);
        return Response.ok().status(Status.FOUND).build();
    }
}

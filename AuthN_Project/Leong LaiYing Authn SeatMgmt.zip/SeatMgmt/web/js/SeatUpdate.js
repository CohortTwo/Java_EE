function dispData(seatJSON) {
    var formObj = document.getElementById('uForm');
    formObj.id.value = seatJSON.id;
    formObj.row.value = seatJSON.row;
    formObj.column.value = seatJSON.column;
    formObj.section.value = seatJSON.section;
     document.getElementById("isBooked").checked = seatJSON.isBooked;
    formObj.instruction.value = seatJSON.instruction;

}

function findSeatbyID(e) {
    var queryString = window.location.search;
    var urlParams = new URLSearchParams(queryString);
    var id = urlParams.get("id");
    var http = new XMLHttpRequest();
    http.onreadystatechange = function () {

        if (http.readyState === 4) {
            var seatJSON = JSON.parse(http.responseText);
            console.log(seatJSON);
            dispData(seatJSON);
        }
    };
    console.log("here id " + id);
    http.open("GET", "http://localhost:7001/SeatMgmt/resources/seats/" + id);
    http.send();
}

function updateSeat() {
    var jsonString = JSON.stringify(Object.fromEntries(new FormData(document.forms.namedItem("uForm")).entries()));
    var id = document.getElementById("uForm").elements.namedItem("id").value;

    console.log(jsonString);
    var http  = new XMLHttpRequest();
    http.open("PUT", "http://localhost:7001/SeatMgmt/resources/seats/" + id);
    http.setRequestHeader('Content-Type', 'application/json');
    http.send(jsonString);
    history.pushState({}, null, "seatList.jsp");
}



function insertSeat() {

    var jsonString = JSON.stringify(Object.fromEntries(new FormData(document.forms.namedItem("cForm")).entries()));
    console.log(jsonString);
    console.log(document.getElementById("cForm"));
    var XHR = new XMLHttpRequest();
    XHR.open("POST", "http://localhost:7001/SeatMgmt/resources/seats");
    XHR.setRequestHeader('Content-Type', 'application/json');
    XHR.send(jsonString);
    history.pushState({}, null, "jsp/seatList.jsp");
}

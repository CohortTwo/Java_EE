/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.demo.auth;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.sql.DataSource;

/**
 *
 * @author User
 */
@Stateless
public class AuthBean {

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
    @Resource(name = "/jdbc/oraDS")
    DataSource datasource;
    Connection connection;

    public Boolean LogInStatus(String userid) throws SQLException {
        connection = datasource.getConnection();
        String query = "SELECT INUSE from HR.AUTH_TBL where USERID='" + userid + "'";
        Statement statement = connection.createStatement();
        ResultSet resultset = statement.executeQuery(query);
        if (resultset.next()) {
            if (resultset.getInt(1) == 1) {
                System.out.println("This user account, " + userid + " has already been logged in.");
                connection.close();
                return true;
            }
        }
        connection.close();
        return false;
    }

    public String LogInFunction(String userid, String password) throws SQLException {
        connection = datasource.getConnection();
        String query = "SELECT USERNAME FROM HR.AUTH_TBL where USERID='" + userid + "' and PASSWORD='" + password + "' ";
        Statement statement = connection.createStatement();
        ResultSet resultset = statement.executeQuery(query);
        if (resultset.next()) {
            String userName = resultset.getString(1);
            System.out.println("Welcome, " + userName);
            connection.close();
            return userName.trim();
        } else {
            connection.close();
            System.out.println("Please enter valid userid and/or password.");
            return "invalid";
        }
    }

    //Integer INUSE = 0 means user is logged in
    public void setLogIn(String userid) throws SQLException {
        connection = datasource.getConnection();
        String query = "UPDATE HR.AUTH_TBL SET INUSE=1 WHERE USERID='" + userid + "'";
        Statement statement = connection.createStatement();
        statement.executeQuery(query);
        connection.close();
    }

    //Integer INUSE = 0 means user is not logged in
    public void SetLogout(String userid) throws SQLException {
        connection = datasource.getConnection();
        String query = "UPDATE HR.AUTH_TBL SET INUSE=0 WHERE USERID='" + userid + "'";
        Statement statement = connection.createStatement();
        statement.executeQuery(query);
        connection.close();
    }

}

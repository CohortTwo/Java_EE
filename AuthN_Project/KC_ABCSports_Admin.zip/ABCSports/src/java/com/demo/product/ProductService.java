/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.demo.product;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import javax.enterprise.context.SessionScoped;
import javax.ws.rs.NotFoundException;
/**
 *
 * @author User
 */

public class ProductService implements ProductInterface{

    private static List<Product> products = new ArrayList<Product>();
    
    public ProductService() {
        if (products.isEmpty()) {
            products.add(new Product(100, "ABC", "32", "red", BigDecimal.valueOf(30)));
        }
    }
    
    @Override
    public Product queryBy(int id) {
        for (Product product : products) {
            System.out.println("Displaying product: " + product.getId());
            if (id == product.getId()) {
                System.out.println("Product: " + product);
                return product;
            }
        }
        return null;
    }

    @Override
    public List<Product> queryAll() {
//        products.forEach(e -> System.out.println(e));
        products.forEach(System.out::println);
        return products;
    }

    @Override
    public Product create(Product product) {
        products.add(product);
        System.out.println("Product added: " + product);
        return product;
    }

    @Override
    public Product update(Product product) throws NotFoundException {
        for (Product currentProduct : products) {
            if (product.getId() == currentProduct.getId()) {
                products.remove(currentProduct);
                products.add(product);
                System.out.println("Product updated: " + product);
            }
        }
        return null;
    }

    @Override
    public Product delete(int id) throws NotFoundException {
        Product currentProduct = this.queryBy(id);
        products.remove(currentProduct);
        System.out.println("Product deleted: " + currentProduct);
        return currentProduct;
    } 
}
